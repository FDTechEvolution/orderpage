<?php return array (
  'irazasyed/telegram-bot-sdk' => 
  array (
    'aliases' => 
    array (
      'Telegram' => 'Telegram\\Bot\\Laravel\\Facades\\Telegram',
    ),
    'providers' => 
    array (
      0 => 'Telegram\\Bot\\Laravel\\TelegramServiceProvider',
    ),
  ),
  'laravel/breeze' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Breeze\\BreezeServiceProvider',
    ),
  ),
  'laravel/pail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Pail\\PailServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'linecorp/line-bot-sdk' => 
  array (
    'aliases' => 
    array (
      'LINELiffApi' => 'LINE\\Laravel\\Facades\\LINELiffApi',
      'LINEInsightApi' => 'LINE\\Laravel\\Facades\\LINEInsightApi',
      'LINEMessagingApi' => 'LINE\\Laravel\\Facades\\LINEMessagingApi',
      'LINEMessagingBlobApi' => 'LINE\\Laravel\\Facades\\LINEMessagingBlobApi',
      'LINEManageAudienceApi' => 'LINE\\Laravel\\Facades\\LINEManageAudienceApi',
      'LINEChannelAccessTokenApi' => 'LINE\\Laravel\\Facades\\LINEChannelAccessTokenApi',
      'LINEManageAudienceBlobApi' => 'LINE\\Laravel\\Facades\\LINEManageAudienceBlobApi',
    ),
    'providers' => 
    array (
      0 => 'LINE\\Laravel\\LINEBotServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'phattarachai/thaidate' => 
  array (
    'providers' => 
    array (
      0 => 'Phattarachai\\Thaidate\\ThaidateServiceProvider',
    ),
  ),
  'reliese/laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Reliese\\Coders\\CodersServiceProvider',
    ),
  ),
);