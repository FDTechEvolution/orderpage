<x-app-layout title="{{ $title }}">
    <x-section>
        <x-crm.menu />
    </x-section>
</x-app-layout>
