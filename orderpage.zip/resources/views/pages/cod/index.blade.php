<x-app-layout title="{{ $title }}">
    <x-section>
        <form action="{{ route('cod.index') }}" method="GET">
            <div class="row">
                <div class="col-9 col-lg-4">
                    <x-date-range name="date_range" :startDate="$startDate" :endDate="$endDate"></x-date-range>
                </div>
                <div class="col-3 col-lg-1">
                    <x-button.primary type="submit">OK</x-button.primary>
                </div>

                <div class="col-12 col-lg-7 text-end">
                    <a href="{{ route('cod.upload') }}" class="btn bg-gradient-success"><i
                            class="fa-solid fa-file-excel"></i> อัพโหลดไฟล์
                        COD</a>
                    <small class="d-block">*** รายการยอดเงินที่ได้รับจากขนส่ง</small>
                </div>
            </div>
        </form>
        <hr>
        @php
        $totalAmt =0;
        @endphp
        <div class="row">
            <div class="col-12 order-2">
                <x-table.data-table>
                    <thead>
                        <tr>
                            <th>วันที่สร้าง</th>
                            <th>วันที่ส่ง</th>
                            <th>ลูกค้า</th>
                            <th>ออเดอร์</th>
                            <th>จำนวนเงิน</th>
                            <th>สถานะ</th>
                            <th>รับเงิน COD</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($orders as $item)
                        <tr>
                            <td>
                                <x-label-date :date="$item->orderdate" />
                            </td>
                            <td>{{ $item->shipping_date }}
                                <x-label-date :date="$item->print_date" />
                            </td>
                            <td>{{ $item->customer->fullname }}</td>
                            <td>{{ $item->order_line_des }}</td>
                            <td class="text-end">
                                <x-label-price :amount="$item->totalamt" />
                                @php
                                $totalAmt += $item->totalamt;
                                @endphp
                            </td>
                            <td>
                                <x-order.status status="{{ $item->status }}" />
                            </td>
                            <td></td>
                        </tr>
                        @endforeach
                    </tbody>
                </x-table.data-table>
            </div>
            <div class="col-12 order-1">
                <div class="row col-border ">
                    <div class="col-6 my-2">
                        <div class="text-center">
                            <div class="h1 fw-medium text-success mb-2">
                                <span data-toggle="count" data-count-from="0" data-count-to="{{ sizeof($orders) }}"
                                    data-count-duration="2000" data-count-decimals="2">0</span>
                            </div>
                            <p class="m-0">จำนวนออเดอร์</p>
                        </div>
                    </div>
                    <div class="col-6 my-2">
                        <div class="text-center">
                            <div class="h1 fw-medium text-success mb-2">
                                <span data-toggle="count" data-count-from="0" data-count-to="{{ ($totalAmt) }}"
                                    data-count-duration="2000" data-count-decimals="0">0</span>
                            </div>
                            <p class="m-0">ยอดเงิน COD</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </x-section>
</x-app-layout>