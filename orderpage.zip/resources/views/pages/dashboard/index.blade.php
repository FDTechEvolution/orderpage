<x-app-layout title="">
    <div class="row">

    </div>

</x-app-layout>
