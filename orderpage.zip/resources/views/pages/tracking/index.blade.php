<x-app-layout title="{{ $title }}">
    <x-section>
        <div class="row">
            <div class="col-12">
                <x-table.data-table>
                    <thead>
                        <tr>
                            <th></th>
                        </tr>
                    </thead>
                </x-table.data-table>
            </div>
        </div>
    </x-section>
</x-app-layout>
