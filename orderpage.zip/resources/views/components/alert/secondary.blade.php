<div class="alert alert-secondary" role="alert">
    {{ $slot }}
</div>