@props(['status'=>''])

<div>
    {{ $statuses[$status] }}
</div>