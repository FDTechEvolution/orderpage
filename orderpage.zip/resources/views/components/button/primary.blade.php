<button class="btn btn-primary w-100 fw-medium" {{ $attributes->merge(['type' => 'button','id'=>'']) }}>
    {{ $slot }}
</button>