<button {{ $attributes->merge(['type' => 'submit','id'=>'','class'=>'btn btn-primary fw-medium']) }}>
    <i class="fa-regular fa-floppy-disk"></i> ยืนยัน
</button>