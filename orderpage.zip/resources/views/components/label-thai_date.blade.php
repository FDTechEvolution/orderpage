@props([
'date',
])
<small>{{ thaidate('l j F Y', $date) }}</small>