@props([
'date',
])
<span>{{ thaidate('l j F Y', $date) }}</span>