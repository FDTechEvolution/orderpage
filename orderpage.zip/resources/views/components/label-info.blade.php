<div class="alert alert-info" role="alert">
    {{ $slot }}
</div>