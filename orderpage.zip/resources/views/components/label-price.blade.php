@props([
'amount',
])
{{ number_format($amount,2) }}฿