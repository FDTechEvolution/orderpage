<div {{ $attributes->merge(['id'=>'','class'=>'portlet']) }}>
    <div class="portlet-body">
        {{ $slot }}
    </div>
</div>
