<div class="section rounded mb-3">
    {{ $slot }}
</div>