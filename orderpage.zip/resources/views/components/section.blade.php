<div {{ $attributes->merge(['id'=>'','class'=>'section rounded mb-3']) }}>
    {{ $slot }}
</div>