@props([
'datetime',
])
<small>{{ thaidate('l j F Y H:i', $datetime) }}</small>