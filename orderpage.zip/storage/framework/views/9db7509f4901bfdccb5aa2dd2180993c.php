<div class="row">
    <div class="col-12">
        <a href="<?php echo e(route('crm.index')); ?>" class="btn <?php if($currentRouteName == 'crm.index'): ?> btn-primary <?php else: ?> btn-outline-secondary <?php endif; ?> "><i class="fa-solid fa-gauge"></i> ภาพรวม</a>
        <a href="<?php echo e(route('crm.customer')); ?>" class="btn <?php if($currentRouteName == 'crm.customer'): ?> btn-primary <?php else: ?> btn-outline-secondary <?php endif; ?>"><i class="fa-regular fa-circle-user"></i> ลูกค้า</a>
        <a href="<?php echo e(route('crm.product')); ?>" class="btn <?php if($currentRouteName =='crm.product'): ?> btn-primary <?php else: ?> btn-outline-secondary <?php endif; ?>" style="display: none;"><i class="fa-solid fa-box"></i> สินค้า</a>
    </div>
</div>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/crm/menu.blade.php ENDPATH**/ ?>