<?php echo e($slot); ?>

<?php /**PATH D:\projects\Git\orderpage\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>