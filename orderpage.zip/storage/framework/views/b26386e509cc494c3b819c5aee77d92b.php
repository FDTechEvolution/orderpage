<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false,'name'=>'','label'=>'','required'=>false,'startDate'=>'','endDate'=>'']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false,'name'=>'','label'=>'','required'=>false,'startDate'=>'','endDate'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="input-group-over position-realtive z-index-1 bg-white ">
    <!-- predefined ranges -->
    <input autocomplete="off" type="text" name="<?php echo e($name); ?>" <?php if($required): echo 'required'; endif; ?>
        class="form-control  rangepicker bg-transparent" data-ranges="true" data-date-format="DD/MM/YYYY"
        data-date-start="<?php echo e($startDate); ?>" data-date-end="<?php echo e($endDate); ?>" data-quick-locale='{
"lang_apply"	: "ตกลง",
"lang_cancel" : "ยกเลิก",
"lang_crange" : "เลือกวันด้วยตัวเอง",
"lang_months"	 : ["มค", "กพ", "มีค", "เมย", "พค", "มิย", "กค", "สค", "กย", "ตค", "พย", "ธค"],
"lang_weekdays" : ["อา", "จ", "อัง", "พ", "พฤ", "ศ", "ส"],

"lang_today"	: "วันนี้",
"lang_yday"	 : "เมื่อวาน",
"lang_7days"	: "7 วันล่าสุด",
"lang_30days" : "30 วันล่าสุด",
"lang_tmonth" : "เดือนนี้",
"lang_lmonth" : "เดือนที่แล้ว"
}'>
    <span class="fi fi-calendar fs-2 mx-4 z-index-n1"></span>
</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/date-range.blade.php ENDPATH**/ ?>