<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['status'=>'']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['status'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<?php if($status == 'DR'): ?>
<span class="badge bg-secondary-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-secondary me-2 animate-pulse-secondary"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'CF'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2 animate-pulse-success"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'P1'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2 animate-pulse-success"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'WS'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2 animate-pulse-success"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'ST'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'DV'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'VO'): ?>
<span class="badge bg-danger-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-danger me-2 animate-pulse-danger"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'VO_RETURN'): ?>
<span class="badge bg-danger-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-danger me-2 animate-pulse-danger"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php elseif($status == 'RECEIVED'): ?>
<span class="badge bg-success-soft rounded-pill d-inline-flex align-items-center">
    <span class="bull bull-lg bg-success me-2 animate-pulse-success"></span>
    <span><?php echo e($statuses[$status]); ?></span>
</span>
<?php endif; ?><?php /**PATH D:\projects\Git\orderpage\resources\views/components/order/status.blade.php ENDPATH**/ ?>