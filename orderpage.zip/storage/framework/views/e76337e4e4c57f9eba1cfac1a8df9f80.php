<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'orderId',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'orderId',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="dropstart">
    <a href="#" class="btn btn-sm btn-light rounded-circle js-stoppropag" data-bs-toggle="dropdown"
        aria-expanded="false" aria-haspopup="true">
        <span class="group-icon">
            <i class="fi fi-dots-vertical-full"></i>
            <i class="fi fi-close"></i>
        </span>
    </a>
    <div class="dropdown-menu dropdown-menu-clean dropdown-click-ignore max-w-220" style="">

        <div class="scrollable-vertical max-vh-50">
            <a href="#" class="dropdown-item text-truncate js-ajax-modal" data-ajax-modal-size="modal-xl"
                data-ajax-modal-backdrop="static" data-href="<?php echo e(route('order.show',['order'=>$orderId])); ?>">
                <i class="fa-solid fa-tv"></i> ดูข้อมูล
            </a>

            <a class="dropdown-item text-truncate" href="<?php echo e(route('order.edit',['order'=>$orderId])); ?>" target="_blank">
                <i class="fi fi-pencil"></i>
                แก้ไข
            </a>

        </div>
    </div>
</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/order/dropdown-menu.blade.php ENDPATH**/ ?>