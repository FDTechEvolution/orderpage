<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false,'name'=>'','label'=>'','required'=>false,'options'=>[],'all'=>true,'default'=>'']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false,'name'=>'','label'=>'','required'=>false,'options'=>[],'all'=>true,'default'=>'']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="form-floating mb-3">
    <select class="form-select" name="<?php echo e($name); ?>" aria-label="" <?php echo e($attributes->merge(['id'=>$name])); ?>>
        <?php if($all): ?>
        <option value="" selected>-- ทั้งหมด --</option>
        <?php endif; ?>
        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>"><?php echo e($text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
    <label for="floatingSelect"><?php echo e($label); ?></label>
</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/selection.blade.php ENDPATH**/ ?>