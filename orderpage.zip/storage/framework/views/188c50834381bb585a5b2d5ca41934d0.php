<div class="alert alert-secondary" role="alert">
    <?php echo e($slot); ?>

</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/alert/secondary.blade.php ENDPATH**/ ?>