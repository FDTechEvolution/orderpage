<div <?php echo e($attributes->merge(['id'=>'','class'=>'portlet'])); ?>>
    <div class="portlet-body">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/card.blade.php ENDPATH**/ ?>