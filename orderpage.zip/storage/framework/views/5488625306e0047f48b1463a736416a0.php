<div class="section rounded mb-3">
    <?php echo e($slot); ?>

</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/section.blade.php ENDPATH**/ ?>