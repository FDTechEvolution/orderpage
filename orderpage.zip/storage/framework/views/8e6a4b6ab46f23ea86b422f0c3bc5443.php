<button <?php echo e($attributes->merge(['type' => 'button','id'=>'','class'=>'js-ajax-modal','data-href'=>''])); ?>

    data-ajax-modal-size="modal-md" data-ajax-modal-centered="true">
    <?php echo e($slot); ?>

</button><?php /**PATH D:\projects\Git\orderpage\resources\views/components/button/ajax.blade.php ENDPATH**/ ?>