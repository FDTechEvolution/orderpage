<div class="modal-header">
    <h4 class="modal-title" id="staticBackdropLabel"><?php if(isset($title)): ?>
        <?php echo e($title); ?>

        <?php endif; ?></h4>
    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
</div>

<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->yieldContent('script'); ?><?php /**PATH D:\projects\Git\orderpage\resources\views/layouts/ajax_modal.blade.php ENDPATH**/ ?>