<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'shippingUrl'=>[
'FLASH'=>'https://flashexpress.co.th/fle/tracking?se=',
'KERRY'=>'https://th.kerryexpress.com/th/track/v2/?track=',
'THPOST_POSTONE'=>'https://track.thailandpost.co.th/?trackNumber=',
'THPOST_PROSHIP'=>'https://track.thailandpost.co.th/?trackNumber=',
'NO'=>''],'trackingno'=>'','shipping'=>'NO']
));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'shippingUrl'=>[
'FLASH'=>'https://flashexpress.co.th/fle/tracking?se=',
'KERRY'=>'https://th.kerryexpress.com/th/track/v2/?track=',
'THPOST_POSTONE'=>'https://track.thailandpost.co.th/?trackNumber=',
'THPOST_PROSHIP'=>'https://track.thailandpost.co.th/?trackNumber=',
'NO'=>''],'trackingno'=>'','shipping'=>'NO']
), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<a href="<?php echo e($shippingUrl[strtoupper($shipping)]); ?><?php echo e($trackingno); ?>" target="_blank"><?php echo e($trackingno); ?></a><?php /**PATH D:\projects\Git\orderpage\resources\views/components/label-trackingno.blade.php ENDPATH**/ ?>