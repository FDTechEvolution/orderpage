<div class="container-doc mt-2 mb-2" bis_skin_checked="1">
    <div class="card" bis_skin_checked="1">
        <div class="card-body p-4 d-flex" bis_skin_checked="1">

            <svg width="48px" height="48px" xmlns="http://www.w3.org/2000/svg" fill="currentColor" class="bi bi-bookmark-check text-warning" viewBox="0 0 16 16">
                <path fill-rule="evenodd" d="M10.854 5.146a.5.5 0 0 1 0 .708l-3 3a.5.5 0 0 1-.708 0l-1.5-1.5a.5.5 0 1 1 .708-.708L7.5 7.793l2.646-2.647a.5.5 0 0 1 .708 0z"></path>
                <path d="M2 2a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v13.5a.5.5 0 0 1-.777.416L8 13.101l-5.223 2.815A.5.5 0 0 1 2 15.5V2zm2-1a1 1 0 0 0-1 1v12.566l4.723-2.482a.5.5 0 0 1 .554 0L13 14.566V2a1 1 0 0 0-1-1H4z"></path>
            </svg>

            <div class="ps-4" bis_skin_checked="1">
                <?php echo e($slot); ?>

            </div>

        </div>
    </div>
</div>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/help-box.blade.php ENDPATH**/ ?>