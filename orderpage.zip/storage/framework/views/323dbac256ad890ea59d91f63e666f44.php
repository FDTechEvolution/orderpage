<div>
    <?php echo e(dd($shippingOptions)); ?>

</div>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/label-shipping.blade.php ENDPATH**/ ?>