<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => ''.e($title).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal06b678ea6fc36cc4d04471936415ef64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06b678ea6fc36cc4d04471936415ef64 = $attributes; } ?>
<?php $component = App\View\Components\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <form action="<?php echo e(route('cod.index')); ?>" method="GET">
            <div class="row">
                <div class="col-9 col-lg-4">
                    <?php if (isset($component)) { $__componentOriginal981b320513511d7b9affa90d6802addb = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal981b320513511d7b9affa90d6802addb = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.date-range','data' => ['name' => 'date_range','startDate' => $startDate,'endDate' => $endDate]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('date-range'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'date_range','startDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($startDate),'endDate' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($endDate)]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal981b320513511d7b9affa90d6802addb)): ?>
<?php $attributes = $__attributesOriginal981b320513511d7b9affa90d6802addb; ?>
<?php unset($__attributesOriginal981b320513511d7b9affa90d6802addb); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal981b320513511d7b9affa90d6802addb)): ?>
<?php $component = $__componentOriginal981b320513511d7b9affa90d6802addb; ?>
<?php unset($__componentOriginal981b320513511d7b9affa90d6802addb); ?>
<?php endif; ?>
                </div>
                <div class="col-3 col-lg-1">
                    <?php if (isset($component)) { $__componentOriginal79c47ff43af68680f280e55afc88fe59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79c47ff43af68680f280e55afc88fe59 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.primary','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?>OK <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $attributes = $__attributesOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__attributesOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $component = $__componentOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__componentOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
                </div>

                <div class="col-12 col-lg-7 text-end">
                    <a href="<?php echo e(route('cod.upload')); ?>" class="btn bg-gradient-success"><i
                            class="fa-solid fa-file-excel"></i> อัพโหลดไฟล์
                        COD</a>
                    <small class="d-block">*** รายการยอดเงินที่ได้รับจากขนส่ง</small>
                </div>
            </div>
        </form>
        <hr>
        <?php
        $totalAmt =0;
        ?>
        <div class="row">
            <div class="col-12 order-2">
                <?php if (isset($component)) { $__componentOriginalfcf285a1eae317d6beb77fa549594189 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcf285a1eae317d6beb77fa549594189 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                    <thead>
                        <tr>
                            <th>วันที่สร้าง</th>
                            <th>วันที่ส่ง</th>
                            <th>ลูกค้า</th>
                            <th>ออเดอร์</th>
                            <th>จำนวนเงิน</th>
                            <th>สถานะ</th>
                            <th>รับเงิน COD</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $item->orderdate]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->orderdate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
                            </td>
                            <td><?php echo e($item->shipping_date); ?>

                                <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $item->print_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->print_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
                            </td>
                            <td><?php echo e($item->customer->fullname); ?></td>
                            <td><?php echo e($item->order_line_des); ?></td>
                            <td class="text-end">
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $item->totalamt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->totalamt)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                                <?php
                                $totalAmt += $item->totalamt;
                                ?>
                            </td>
                            <td>
                                <?php if (isset($component)) { $__componentOriginal73f9b773b0e99831d6746157c0ccee8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b = $attributes; } ?>
<?php $component = App\View\Components\Order\Status::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Order\Status::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => ''.e($item->status).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $attributes = $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $component = $__componentOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
                            </td>
                            <td></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcf285a1eae317d6beb77fa549594189)): ?>
<?php $attributes = $__attributesOriginalfcf285a1eae317d6beb77fa549594189; ?>
<?php unset($__attributesOriginalfcf285a1eae317d6beb77fa549594189); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcf285a1eae317d6beb77fa549594189)): ?>
<?php $component = $__componentOriginalfcf285a1eae317d6beb77fa549594189; ?>
<?php unset($__componentOriginalfcf285a1eae317d6beb77fa549594189); ?>
<?php endif; ?>
            </div>
            <div class="col-12 order-1">
                <div class="row col-border ">
                    <div class="col-6 my-2">
                        <div class="text-center">
                            <div class="h1 fw-medium text-success mb-2">
                                <span data-toggle="count" data-count-from="0" data-count-to="<?php echo e(sizeof($orders)); ?>"
                                    data-count-duration="2000" data-count-decimals="2">0</span>
                            </div>
                            <p class="m-0">จำนวนออเดอร์</p>
                        </div>
                    </div>
                    <div class="col-6 my-2">
                        <div class="text-center">
                            <div class="h1 fw-medium text-success mb-2">
                                <span data-toggle="count" data-count-from="0" data-count-to="<?php echo e(($totalAmt)); ?>"
                                    data-count-duration="2000" data-count-decimals="0">0</span>
                            </div>
                            <p class="m-0">ยอดเงิน COD</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>


     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $attributes = $__attributesOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $component = $__componentOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__componentOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\projects\Git\orderpage\resources\views/pages/cod/index.blade.php ENDPATH**/ ?>