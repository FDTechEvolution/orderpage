<button class="btn btn-primary w-100 fw-medium" <?php echo e($attributes->merge(['type' => 'button','id'=>''])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH D:\projects\Git\orderpage\resources\views/components/button/primary.blade.php ENDPATH**/ ?>