<button <?php echo e($attributes->merge(['type' => 'button','id'=>'','class'=>'btn btn-primary fw-medium'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH D:\projects\Git\orderpage\resources\views/components/button/primary.blade.php ENDPATH**/ ?>