<?php if (isset($component)) { $__componentOriginal69dc84650370d1d4dc1b42d016d7226b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b = $attributes; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\GuestLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="container">
        <div class="text-center mb-1">
            <h1 class="fw-bold">ค้นหาข้อมูลลูกค้า</h1>
            <p class="lead m-0">
                กรุณาระบุหมายเลขโทรศัพท์ของลูกค้า
            </p>
        </div>
        <?php if (isset($component)) { $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form','data' => ['action' => ''.e(route('guest.find')).'','method' => 'GET']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('guest.find')).'','method' => 'GET']); ?>
            <div class="row">
                <div class="col-12 col-lg-4 offset-lg-4 text-center">
                    <input class="form-control mb-3" type="number" name="mobileno" id="mobileno" required
                        value="<?php echo e($mobileno); ?>">
                    <button class="btn btn-success"><i class="fi fi-search"></i> ค้นหา</button>
                </div>
            </div>
            <?php if(!empty($orders)): ?>
            <hr>
            <div class="row">
                <div class="col-12 col-lg-4 offset-lg-4">

                    <table class="table">
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $customer->orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginal73f9b773b0e99831d6746157c0ccee8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b = $attributes; } ?>
<?php $component = App\View\Components\Order\Status::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Order\Status::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => ''.e($order->status).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $attributes = $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $component = $__componentOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?><br>
                                    <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $order->record_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->record_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?><br>
                                    <?php echo e($order->payment_method); ?><br>
                                    <strong class="text-danger">
                                        <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => ''.e($order->totalamt).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => ''.e($order->totalamt).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                                    </strong>
                                </td>
                                <td>
                                    <p><strong><?php echo e($customer->fullname); ?></strong> <small><?php echo e(sprintf('%s %s %s %s %s
                                            โทร
                                            %s',$customer->address_line1,$customer->subdistrict,$customer->district,$customer->province,$customer->zipcode,$customer->mobile)); ?></small>
                                    </p>
                                    <strong><?php echo e($order->order_line_des); ?></strong>
                                    <p>
                                        <?php echo e($order->shipping->name); ?>:
                                        <?php if (isset($component)) { $__componentOriginal48b27ae803078dab117147f78dcfd5a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal48b27ae803078dab117147f78dcfd5a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-trackingno','data' => ['trackingno' => ''.e($order->trackingno).'','shipping' => ''.e($order->shipping->code).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-trackingno'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['trackingno' => ''.e($order->trackingno).'','shipping' => ''.e($order->shipping->code).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $attributes = $__attributesOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $component = $__componentOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__componentOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
                                    </p>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php endif; ?>


         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $attributes = $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $component = $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $attributes = $__attributesOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__attributesOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b)): ?>
<?php $component = $__componentOriginal69dc84650370d1d4dc1b42d016d7226b; ?>
<?php unset($__componentOriginal69dc84650370d1d4dc1b42d016d7226b); ?>
<?php endif; ?><?php /**PATH D:\projects\Git\orderpage\resources\views/pages/guest/find.blade.php ENDPATH**/ ?>