<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => ''.e($title).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12 col-lg-6 offset-lg-3">
            <?php if (isset($component)) { $__componentOriginal06b678ea6fc36cc4d04471936415ef64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06b678ea6fc36cc4d04471936415ef64 = $attributes; } ?>
<?php $component = App\View\Components\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <form action="<?php echo e(route('cod.storeUpload')); ?>" method="POST" novalidate
                    class="bs-validate p-4 p-md-5 card rounded-xl" data-error-scroll-up="true"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-12">
                            <div class="mb-3">
                                <label for="formFile" class="form-label">ไฟล์ Excel</label>
                                <input class="form-control" type="file" id="file" name="file"
                                    accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel"
                                    required>
                            </div>
                        </div>
                        <div class="col-12">
                            <?php if (isset($component)) { $__componentOriginal79c47ff43af68680f280e55afc88fe59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79c47ff43af68680f280e55afc88fe59 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.primary','data' => ['type' => 'submit']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit']); ?><i class="fa-solid fa-upload"></i> อัพโหลดไฟล์
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $attributes = $__attributesOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__attributesOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $component = $__componentOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__componentOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
                        </div>
                    </div>
                </form>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $attributes = $__attributesOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $component = $__componentOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__componentOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
        </div>
    </div>

    <?php if(isset($columns)): ?>
    <?php if (isset($component)) { $__componentOriginal06b678ea6fc36cc4d04471936415ef64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06b678ea6fc36cc4d04471936415ef64 = $attributes; } ?>
<?php $component = App\View\Components\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="row">
            <div class="col-12">
                <?php if (isset($component)) { $__componentOriginalb60823a6187f6a1eefa1cdbf75085153 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb60823a6187f6a1eefa1cdbf75085153 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.alert.secondary','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('alert.secondary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?><?php echo e(sprintf('พบข้อมูลที่อ่านได้จำนวน %d แถว (รวม header)',sizeof($data))); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb60823a6187f6a1eefa1cdbf75085153)): ?>
<?php $attributes = $__attributesOriginalb60823a6187f6a1eefa1cdbf75085153; ?>
<?php unset($__attributesOriginalb60823a6187f6a1eefa1cdbf75085153); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb60823a6187f6a1eefa1cdbf75085153)): ?>
<?php $component = $__componentOriginalb60823a6187f6a1eefa1cdbf75085153; ?>
<?php unset($__componentOriginalb60823a6187f6a1eefa1cdbf75085153); ?>
<?php endif; ?>
            </div>
            <div class="col-12 col-lg-4">
                <?php if (isset($component)) { $__componentOriginal73aae2ee88c89d22d60718eaad280f0c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.selection','data' => ['label' => 'เลือกคอลัมน์เลขพัสดุ','options' => $columns,'name' => 'column_tracking','all' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'เลือกคอลัมน์เลขพัสดุ','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columns),'name' => 'column_tracking','all' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $attributes = $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $component = $__componentOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
            </div>

            <div class="col-12 col-lg-4">
                <?php if (isset($component)) { $__componentOriginal73aae2ee88c89d22d60718eaad280f0c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.selection','data' => ['label' => 'เลือกคอลัมน์ยอดเงินที่ได้รับ','options' => $columns,'name' => 'column_amount','all' => false]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'เลือกคอลัมน์ยอดเงินที่ได้รับ','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($columns),'name' => 'column_amount','all' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(false)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $attributes = $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $component = $__componentOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
            </div>
            <div class="col-12 col-lg-2">
                <?php if (isset($component)) { $__componentOriginal79c47ff43af68680f280e55afc88fe59 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal79c47ff43af68680f280e55afc88fe59 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.primary','data' => ['id' => 'bt_confirm']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'bt_confirm']); ?> ยืนยันข้อมูล
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $attributes = $__attributesOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__attributesOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal79c47ff43af68680f280e55afc88fe59)): ?>
<?php $component = $__componentOriginal79c47ff43af68680f280e55afc88fe59; ?>
<?php unset($__componentOriginal79c47ff43af68680f280e55afc88fe59); ?>
<?php endif; ?>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-12">
                <table class="table table-sm" id="tb_file_result">
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr id="<?php echo e($index); ?>">
                            <?php $__currentLoopData = $row; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=> $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td>
                                <?php echo e($column); ?>

                                <input type="hidden" name="c_<?php echo e($index); ?>_<?php echo e($i); ?>" id="c_<?php echo e($index); ?>_<?php echo e($i); ?>"
                                    value="<?php echo e($column); ?>">
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td id="c_<?php echo e($index); ?>"></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $attributes = $__attributesOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $component = $__componentOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__componentOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>

    <?php $__env->startSection('script'); ?>
    <script>
        const api = '<?php echo e(env('APP_URL')); ?>';
        $(document).ready(function(){
            $('#bt_confirm').on('click',function(){
                pageLoader();

                let column_tracking = $('#column_tracking').val();
                let column_amount = $('#column_amount').val();

                let len = $('#tb_file_result > tbody > tr').length;
                $('#tb_file_result > tbody > tr').each(function(index, tr) {
                    let rowId = tr.id;
                    let trackingno = $('#c_'+rowId+'_'+column_tracking).val();
                    let amount = $('#c_'+rowId+'_'+column_amount).val();

                    if(!$.isNumeric(amount)){
                        amount = 0;
                    }
                    $.get(api+'/api/v1/cod/check/'+trackingno+'/'+amount, { })
                    .done(function(response) {
                        // ทำงานเมื่อ request สำเร็จ
                        if(response.success){
                            $('#c_'+rowId).append('<small><i class="fa-solid fa-check text-success"></i> '+response.message+'</small>');
                        }else{
                            $('#c_'+rowId).append('<small><i class="fa-solid fa-circle-exclamation text-danger"></i> '+response.message+'</small>');
                        }

                    })
                    .fail(function(error) {
                        // ทำงานเมื่อ request ล้มเหลว
                        console.error('Request failed:', error);
                        $('#c_'+rowId).append('<i class="fa-solid fa-circle-exclamation text-danger"></i>');
                    });

                    if (index === (len - 1)){
                        hidePageLoader();
                    }
                });


            });
        });
    </script>
    <?php $__env->stopSection(); ?>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\projects\Git\orderpage\resources\views/pages/cod/upload.blade.php ENDPATH**/ ?>