<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- up to 10% speed up for external res -->
    <link rel="dns-prefetch" href="https://fonts.googleapis.com/">
    <link rel="dns-prefetch" href="https://fonts.gstatic.com/">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/">
    <!-- preloading icon font is helping to speed up a little bit -->
    <link rel="preload" href="<?php echo e(asset('assets/fonts/flaticon/Flaticon.woff2')); ?>" as="font" type="font/woff2"
        crossorigin>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/core.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/vendor_bundle.min.css')); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;700&display=swap">

</head>

<body>
    <div class="section">
        <?php echo e($slot); ?>

    </div>

    <script src="<?php echo e(asset('assets/js/core.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor_bundle.min.js')); ?>"></script>
</body>

</html><?php /**PATH D:\projects\Git\orderpage\resources\views/layouts/guest.blade.php ENDPATH**/ ?>