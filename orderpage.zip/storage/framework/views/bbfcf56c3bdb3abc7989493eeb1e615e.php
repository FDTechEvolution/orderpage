<div class="row">
    <div class="col-12 col-lg-6">
        <?php if (isset($component)) { $__componentOriginal267759028f6d98daa527110378783a2e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal267759028f6d98daa527110378783a2e = $attributes; } ?>
<?php $component = App\View\Components\SelectionProductCategory::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('selection-product-category'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\SelectionProductCategory::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal267759028f6d98daa527110378783a2e)): ?>
<?php $attributes = $__attributesOriginal267759028f6d98daa527110378783a2e; ?>
<?php unset($__attributesOriginal267759028f6d98daa527110378783a2e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal267759028f6d98daa527110378783a2e)): ?>
<?php $component = $__componentOriginal267759028f6d98daa527110378783a2e; ?>
<?php unset($__componentOriginal267759028f6d98daa527110378783a2e); ?>
<?php endif; ?>
    </div>
    <div class="col-12 col-lg-6">
        <?php if (isset($component)) { $__componentOriginal73aae2ee88c89d22d60718eaad280f0c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.selection','data' => ['label' => 'สินค้า','name' => 'product_id','options' => []]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('selection'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => 'สินค้า','name' => 'product_id','options' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $attributes = $__attributesOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__attributesOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c)): ?>
<?php $component = $__componentOriginal73aae2ee88c89d22d60718eaad280f0c; ?>
<?php unset($__componentOriginal73aae2ee88c89d22d60718eaad280f0c); ?>
<?php endif; ?>
    </div>
</div>


<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#product_category_id').change(function() {
            let categoryId = $(this).val();
            $('#product_id').html('<option value="">กำลังโหลด...</option>');

            $.ajax({
                url: "<?php echo e(route('apiProduct.byCategory')); ?>"
                , type: "GET"
                , data: {
                    product_category_id: categoryId
                }
                , success: function(data) {
                    let options = '<option value="">-- ทั้งหมด --</option>';
                    $.each(data, function(key, value) {
                        options += `<option value="${key}">${value}</option>`;
                    });
                    $('#product_id').html(options);
                }
            });
        });
    });

</script>
<?php $__env->stopSection(); ?>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/selection-product-group.blade.php ENDPATH**/ ?>