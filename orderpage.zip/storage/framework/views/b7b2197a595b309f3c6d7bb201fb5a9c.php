<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
'orders'=>[],
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
'orders'=>[],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div>
    <?php if (isset($component)) { $__componentOriginalfcf285a1eae317d6beb77fa549594189 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfcf285a1eae317d6beb77fa549594189 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.table.data-table','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('table.data-table'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <thead>
            <tr>
                <th>วันที่สร้าง</th>
                <th>วันที่ปริ้น</th>
                <th>ลูกค้า</th>
                <th>ออเดอร์</th>

                <th>เลขพัสดุ</th>
                <th>จำนวนเงิน</th>
                <th width="100"></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $order->orderdate]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->orderdate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
                </td>
                <td>
                    <?php if (isset($component)) { $__componentOriginale5e586dc9cff5cb2211c6e68cddbd0d5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale5e586dc9cff5cb2211c6e68cddbd0d5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-datetime','data' => ['datetime' => $order->print_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-datetime'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['datetime' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->print_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale5e586dc9cff5cb2211c6e68cddbd0d5)): ?>
<?php $attributes = $__attributesOriginale5e586dc9cff5cb2211c6e68cddbd0d5; ?>
<?php unset($__attributesOriginale5e586dc9cff5cb2211c6e68cddbd0d5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale5e586dc9cff5cb2211c6e68cddbd0d5)): ?>
<?php $component = $__componentOriginale5e586dc9cff5cb2211c6e68cddbd0d5; ?>
<?php unset($__componentOriginale5e586dc9cff5cb2211c6e68cddbd0d5); ?>
<?php endif; ?>
                </td>
                <td>
                    <strong><?php echo e($order->customer->fullname); ?></strong>
                    <small><?php echo e(sprintf('%s ตำบล%s อำเภอ%s จังหวัด%s
                        %s โทร
                        %s',$order->customer->address_line1,$order->customer->subdistrict,$order->customer->district,$order->customer->province,$order->customer->zipcode,$order->customer->mobile)); ?></small>
                </td>
                <td><small><?php echo e($order->order_line_des); ?></small></td>

                <td>
                    <?php echo e($order->shipping->name); ?>:
                    <?php if (isset($component)) { $__componentOriginal48b27ae803078dab117147f78dcfd5a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal48b27ae803078dab117147f78dcfd5a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-trackingno','data' => ['trackingno' => $order->trackingno,'shipping' => $order->shipping->code]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-trackingno'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['trackingno' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->trackingno),'shipping' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->shipping->code)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $attributes = $__attributesOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $component = $__componentOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__componentOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
                </td>
                <td class="text-end">
                    <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $order->totalamt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->totalamt)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?><br />
                    <?php if (isset($component)) { $__componentOriginal73f9b773b0e99831d6746157c0ccee8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b = $attributes; } ?>
<?php $component = App\View\Components\Order\Status::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Order\Status::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => ''.e($order->status).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $attributes = $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $component = $__componentOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
                </td>
                <td class="text-end">
                    <?php if (isset($component)) { $__componentOriginal57eb253daebbd4b189eec28e37e4e8e3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal57eb253daebbd4b189eec28e37e4e8e3 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.order.dropdown-menu','data' => ['orderId' => $order->id]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.dropdown-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['orderId' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->id)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal57eb253daebbd4b189eec28e37e4e8e3)): ?>
<?php $attributes = $__attributesOriginal57eb253daebbd4b189eec28e37e4e8e3; ?>
<?php unset($__attributesOriginal57eb253daebbd4b189eec28e37e4e8e3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal57eb253daebbd4b189eec28e37e4e8e3)): ?>
<?php $component = $__componentOriginal57eb253daebbd4b189eec28e37e4e8e3; ?>
<?php unset($__componentOriginal57eb253daebbd4b189eec28e37e4e8e3); ?>
<?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfcf285a1eae317d6beb77fa549594189)): ?>
<?php $attributes = $__attributesOriginalfcf285a1eae317d6beb77fa549594189; ?>
<?php unset($__attributesOriginalfcf285a1eae317d6beb77fa549594189); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfcf285a1eae317d6beb77fa549594189)): ?>
<?php $component = $__componentOriginalfcf285a1eae317d6beb77fa549594189; ?>
<?php unset($__componentOriginalfcf285a1eae317d6beb77fa549594189); ?>
<?php endif; ?>
</div><?php /**PATH D:\projects\Git\orderpage\resources\views/components/order/table.blade.php ENDPATH**/ ?>