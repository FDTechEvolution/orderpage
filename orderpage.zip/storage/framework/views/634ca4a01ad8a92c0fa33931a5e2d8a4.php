<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <table class="table table-sm" id="tb-data">
            <thead>
                <tr>
                    <th>#</th>
                    <th>วันที่</th>
                    <th>ลูกค้า</th>
                    <th>ที่อยู่ลูกค้า</th>
                    <th>เบอร์โทร</th>
                    <th>รายการสั่งซื้อ</th>
                    <th>การชำระเงิน</th>
                    <th>สถานะ</th>
                    <th>จำนวนเงิน</th>
                </tr>
            </thead>
            <tbody id="orderTable">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td>
                        <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $order->orderdate]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->orderdate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
                    </td>
                    <td><?php echo e($order->customer->fullname); ?></td>
                    <td><?php echo e(sprintf('%s %s %s %s %s',$order->customer->address_line1,$order->customer->subdistrict,$order->customer->district,$order->customer->province,$order->customer->zipcode)); ?></td>
                    <td><?php echo e($order->customer->mobile); ?></td>
                    <td><?php echo e($order->order_line_des); ?></td>
                    <td><?php echo e($order->payment_method); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td class="subtotal text-end"><?php echo e(number_format($order->totalamt,2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td class="text-end">รวม</td>
                    <td id="totalSum">0</td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function calculateTotal() {
        let total = 0;
        document.querySelectorAll("#orderTable tr").forEach(row => {
            let subtotal = parseFloat(row.querySelector(".subtotal").textContent) || 0;
            //console.log(subtotal);
            total += subtotal;
        });
        document.getElementById("totalSum").textContent = total.toFixed(2);
    }

    calculateTotal(); // คำนวณทันทีเมื่อโหลดหน้า

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.export', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\projects\Git\orderpage\resources\views/pages/report/pull_order.blade.php ENDPATH**/ ?>