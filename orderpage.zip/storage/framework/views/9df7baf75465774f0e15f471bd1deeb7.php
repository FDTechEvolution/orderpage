<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve(['title' => ''.e($title).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if (isset($component)) { $__componentOriginal06b678ea6fc36cc4d04471936415ef64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06b678ea6fc36cc4d04471936415ef64 = $attributes; } ?>
<?php $component = App\View\Components\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'p-4 mb-2']); ?>
        <div class="row">
            <div class="col">
                <h3>
                    <?php if (isset($component)) { $__componentOriginal73f9b773b0e99831d6746157c0ccee8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b = $attributes; } ?>
<?php $component = App\View\Components\Order\Status::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Order\Status::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => ''.e($order->status).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $attributes = $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $component = $__componentOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
                </h3>


                <ul class="list-unstyled m-0 p-0">
                    <li class="list-item">
                        <span class="text-muted small">
                            สร้างเมื่อ:
                            <?php if (isset($component)) { $__componentOriginalf2ec803411b178f97118de73602d8fa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2ec803411b178f97118de73602d8fa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-thai_datetime','data' => ['date' => $order->record_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-thai_datetime'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->record_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2ec803411b178f97118de73602d8fa0)): ?>
<?php $attributes = $__attributesOriginalf2ec803411b178f97118de73602d8fa0; ?>
<?php unset($__attributesOriginalf2ec803411b178f97118de73602d8fa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2ec803411b178f97118de73602d8fa0)): ?>
<?php $component = $__componentOriginalf2ec803411b178f97118de73602d8fa0; ?>
<?php unset($__componentOriginalf2ec803411b178f97118de73602d8fa0); ?>
<?php endif; ?>
                        </span>
                        <span class="text-muted small">
                            | ปริ้นเมื่อ:
                            <?php if (isset($component)) { $__componentOriginalf2ec803411b178f97118de73602d8fa0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf2ec803411b178f97118de73602d8fa0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-thai_datetime','data' => ['date' => $order->print_date]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-thai_datetime'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->print_date)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf2ec803411b178f97118de73602d8fa0)): ?>
<?php $attributes = $__attributesOriginalf2ec803411b178f97118de73602d8fa0; ?>
<?php unset($__attributesOriginalf2ec803411b178f97118de73602d8fa0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf2ec803411b178f97118de73602d8fa0)): ?>
<?php $component = $__componentOriginalf2ec803411b178f97118de73602d8fa0; ?>
<?php unset($__componentOriginalf2ec803411b178f97118de73602d8fa0); ?>
<?php endif; ?>
                        </span>
                    </li>
                    <li class="list-item">
                        #<?php echo e($order->ordercode); ?>

                        <?php if($order->payment_method=='cod'): ?>
                        <?php if (isset($component)) { $__componentOriginal0a5be77946a395877e6302c3ae23881c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0a5be77946a395877e6302c3ae23881c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-cd-receive','data' => ['isactive' => $order->is_cod_received]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-cd-receive'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['isactive' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->is_cod_received)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0a5be77946a395877e6302c3ae23881c)): ?>
<?php $attributes = $__attributesOriginal0a5be77946a395877e6302c3ae23881c; ?>
<?php unset($__attributesOriginal0a5be77946a395877e6302c3ae23881c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0a5be77946a395877e6302c3ae23881c)): ?>
<?php $component = $__componentOriginal0a5be77946a395877e6302c3ae23881c; ?>
<?php unset($__componentOriginal0a5be77946a395877e6302c3ae23881c); ?>
<?php endif; ?>
                        <?php endif; ?>


                    </li>
                </ul>

            </div>

            <div class="col-md-6 text-md-end">
                <a class="btn btn-sm btn-warning rounded-pill" href="#" data-bs-toggle="modal"
                    data-bs-target="#modal-change-status">
                    <span class="small"><i class="fa-solid fa-repeat"></i> เปลี่ยนสถานะออเดอร์</span>
                </a>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $attributes = $__attributesOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $component = $__componentOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__componentOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>

    <div class="row g-2">
        <div class="col">

            <!-- Order items -->
            <div class="card border-0 h-100">

                <div class="card-body p-4 h-100">

                    <div class="table-responsive-md mb-3">
                        <table class="table table-align-middle mb-0" role="grid">
                            <thead>
                                <tr>
                                    <th class="small text-muted" style="width:70px">
                                        <!-- image -->
                                    </th>
                                    <th class="small text-muted">สินค้า</th>
                                    <th class="small text-muted text-end" style="width:150px">จำนวน</th>
                                    <th class="small text-muted text-end">ราคาต่อหน่วย</th>
                                    <th class="small text-muted text-end">ราคารวม</th>
                                    <th class="small text-muted" style="width:64px">
                                        <!-- options -->
                                    </th>
                                </tr>
                            </thead>
                            <tbody id="checkall-list">
                                <?php $__currentLoopData = $order->orderLines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="align-middle">
                                        <i class="fa-solid fa-bag-shopping fs-2 text-secondary"></i>
                                    </td>
                                    <td>
                                        <strong class="d-block fw-medium"><?php echo e($item->product->name); ?></strong>
                                        <span class="d-block text-muted small"></span>
                                    </td>
                                    <td class="text-end"><?php echo e($item->qty); ?></td>
                                    <td class="text-end"></td>
                                    <td class="text-end">
                                        <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $item->amount]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->amount)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                                    </td>
                                    <td class="dropstart text-end">
                                        <!-- options -->
                                        <a class="btn btn-sm btn-light btn-ghost btn-icon text-muted rounded-circle"
                                            href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            <span class="group-icon">
                                                <svg width="18px" height="18px" viewBox="0 0 16 16"
                                                    xmlns="http://www.w3.org/2000/svg" fill="currentColor">
                                                    <path fill-rule="evenodd"
                                                        d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z">
                                                    </path>
                                                </svg>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="18px" height="18px"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <line x1="18" y1="6" x2="6" y2="18"></line>
                                                    <line x1="6" y1="6" x2="18" y2="18"></line>
                                                </svg>
                                            </span>
                                        </a>
                                        <ul class="dropdown-menu dropdown-menu-clean">
                                            <li>
                                                <?php if (isset($component)) { $__componentOriginal4ddc67d99274d91295303ffa5f3e3677 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-ajax','data' => ['class' => 'dropdown-item','href' => ''.e(route('modalOrderLine.edit',['modalOrderLine'=>$item->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('link-ajax'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'dropdown-item','href' => ''.e(route('modalOrderLine.edit',['modalOrderLine'=>$item->id])).'']); ?>
                                                    <svg class="text-muted" width="18px" height="18px"
                                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                        fill="none" stroke="currentColor" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round">
                                                        <path d="M12 20h9"></path>
                                                        <path
                                                            d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z">
                                                        </path>
                                                    </svg>
                                                    <span>Edit</span>
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $attributes = $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $component = $__componentOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>

                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#">
                                                    <svg class="text-danger" width="18px" height="18px"
                                                        xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                                        fill="none" stroke="currentColor" stroke-width="2"
                                                        stroke-linecap="round" stroke-linejoin="round">
                                                        <polyline points="3 6 5 6 21 6"></polyline>
                                                        <path
                                                            d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2">
                                                        </path>
                                                        <line x1="10" y1="11" x2="10" y2="17"></line>
                                                        <line x1="14" y1="11" x2="14" y2="17"></line>
                                                    </svg>
                                                    <span class="w-100">Remove</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>

                    <div class="row g-4">

                        <div class="order-1 order-md-2 col-md-3 text-end">

                            <button type="button" class="btn btn-sm btn-light" data-bs-toggle="modal"
                                data-bs-target="#item-add">
                                <svg width="18px" height="18px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                    fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round">
                                    <line x1="12" y1="5" x2="12" y2="19"></line>
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                </svg>
                                <span>สินค้า</span>
                            </button>
                            <!-- Modal : item add -->
                            <div class="modal fade" id="item-add" tabindex="-1" aria-labelledby="item-add-label"
                                aria-hidden="true">
                                <form method="post" action="#"
                                    class="form-validate modal-dialog modal-md modal-dialog-centered text-start">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="item-add-label">Product add</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">

                                            <!-- product : search -->
                                            <div class="form-floating">
                                                <input type="text" class="form-control" id="p-search" name="p-search"
                                                    placeholder="Product Search">
                                                <label for="p-search">Search product...</label>

                                                <div class="form-check mt-2">
                                                    <input class="form-check-input form-check-input-primary"
                                                        type="checkbox" value="1" id="item-as-gift">
                                                    <label class="form-check-label" for="item-as-gift">
                                                        Add item as gift
                                                    </label>
                                                </div>
                                                <div class="mt-2" id="search-container">
                                                    <div class="py-2">
                                                        <!-- appended item -->
                                                        <a href="#!" class="link-normal">
                                                            <svg height="18px" xmlns="http://www.w3.org/2000/svg"
                                                                viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                                stroke-width="2" stroke-linecap="round"
                                                                stroke-linejoin="round">
                                                                <line x1="18" y1="6" x2="6" y2="18"></line>
                                                                <line x1="6" y1="6" x2="18" y2="18"></line>
                                                            </svg>
                                                        </a>
                                                        <a href="#!" class="text-decoration-none ms-2">Product title -
                                                            appended here</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="submit" class="btn btn-primary">
                                                <svg width="18px" height="18px" xmlns="http://www.w3.org/2000/svg"
                                                    viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                                    stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <polyline points="20 6 9 17 4 12"></polyline>
                                                </svg>
                                                <span>Add</span>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>

                        </div>
                    </div>

                    <div class="row g-4 justify-content-end my-2">
                        <div class="col">

                        </div>
                        <div class="col-md-8 col-lg-7 text-end">
                            <dl class="row mb-0">
                                <dt class="col-6">ราคารวม:</dt>
                                <dd class="col-6">
                                    <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $order->totalamt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->totalamt)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                                </dd>

                                <dt class="col-6">ลดราคา:</dt>
                                <dd class="col-6">0.00</dd>

                                <dt class="col-6">ค่าส่ง:</dt>
                                <dd class="col-6">0.00</dd>

                                <dt class="col-6">ภาษี:</dt>
                                <dd class="col-6">0.00</dd>

                                <dt class="col-6 fw-bold text-primary">รวมทั้งสิ้น:</dt>
                                <dd class="col-6 fw-bold text-primary fs-4">
                                    <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $order->totalamt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->totalamt)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
                                </dd>
                            </dl>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h4 class="h5"><i class="fa-solid fa-clock-rotate-left"></i> ประวัติการแก้ไข</h4>
                        </div>
                        <div class="col-12">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>วันที่ทำรายการ</th>
                                            <th>รายการ</th>
                                            <th>รายละเอียด</th>
                                            <th>ผู้ทำรายการ</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $order->orderLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($log->created_at); ?></td>
                                            <td><?php echo e($log->title); ?></td>
                                            <td><small><?php echo e($log->description); ?></small></td>
                                            <td><?php echo e($log->user->name); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer p-4">

                </div>
            </div>
            <!-- /Order items -->

        </div>

        <div class="col-xl-4">
            <div class="card border-0 h-100">

                <!-- Customer -->
                <div class="card-header p-4 mb-3">
                    <div class="fw-bold d-flex align-items-center mb-3">
                        <span class="w-100">ลูกค้า</span>
                        <?php if (isset($component)) { $__componentOriginal4ddc67d99274d91295303ffa5f3e3677 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-ajax','data' => ['href' => ''.e(route('modalCustomer.edit',['modalCustomer'=>$order->customer_id,'order'=>$order->id])).'','class' => 'flex-none link-muted small d-inline-grid gap-auto-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('link-ajax'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('modalCustomer.edit',['modalCustomer'=>$order->customer_id,'order'=>$order->id])).'','class' => 'flex-none link-muted small d-inline-grid gap-auto-2']); ?>
                            <span class="fw-normal">แก้ไข</span>
                            <svg width="16px" height="16px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $attributes = $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $component = $__componentOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>

                    </div>
                    <div class="d-flex align-items-center">
                        <!-- customer details -->
                        <div class="w-100 ps-4">
                            <ul class="list-unstyled m-0 p-0">
                                <li class="list-item">
                                    <!-- customer name, orders -->
                                    <span class="text-decoration-none fs-5 fw-bold"><?php echo e($order->customer->fullname); ?></span>

                                </li>
                                <li class="list-item">
                                    <span><?php echo e(sprintf('%s ตำบล%s อำเภอ%s จังหวัด%s
                                        %s โทร
                                        %s',$order->customer->address_line1,$order->customer->subdistrict,$order->customer->district,$order->customer->province,$order->customer->zipcode,$order->customer->mobile)); ?></span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="card-body p-4 h-100">
                    <div class="fw-bold d-flex align-items-center mb-3">
                        <span class="w-100"></span>
                        <?php if (isset($component)) { $__componentOriginal4ddc67d99274d91295303ffa5f3e3677 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.link-ajax','data' => ['href' => ''.e(route('modalOrder.edit',['modalOrder'=>$order->id])).'','class' => 'flex-none link-muted small d-inline-grid gap-auto-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('link-ajax'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('modalOrder.edit',['modalOrder'=>$order->id])).'','class' => 'flex-none link-muted small d-inline-grid gap-auto-2']); ?>
                            <span class="fw-normal">แก้ไข</span>
                            <svg width="16px" height="16px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                stroke-linejoin="round">
                                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                            </svg>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $attributes = $__attributesOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__attributesOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677)): ?>
<?php $component = $__componentOriginal4ddc67d99274d91295303ffa5f3e3677; ?>
<?php unset($__componentOriginal4ddc67d99274d91295303ffa5f3e3677); ?>
<?php endif; ?>

                    </div>
                    <ul class="list-unstyled m-0 p-0">
                        <li class="list-item">
                            <strong>Notes:</strong> <?php echo e($order->description); ?>

                        </li>
                        <li class="list-item">
                            รูปแบบการชำระเงิน: <span class="badge bg-primary"><?php echo e($order->payment_method); ?></span>
                        </li>
                        <li class="list-item">
                            ขนส่ง: <span class="badge bg-primary"><?php echo e($order->shipping->name); ?></span>
                            <span class="d-block text-muted small">หมายเลขพัสดุ:
                                <?php if (isset($component)) { $__componentOriginal48b27ae803078dab117147f78dcfd5a9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal48b27ae803078dab117147f78dcfd5a9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-trackingno','data' => ['trackingno' => $order->trackingno,'shipping' => $order->shipping->code]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-trackingno'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['trackingno' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->trackingno),'shipping' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->shipping->code)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $attributes = $__attributesOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__attributesOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal48b27ae803078dab117147f78dcfd5a9)): ?>
<?php $component = $__componentOriginal48b27ae803078dab117147f78dcfd5a9; ?>
<?php unset($__componentOriginal48b27ae803078dab117147f78dcfd5a9); ?>
<?php endif; ?>
                            </span>
                            <span class="d-block text-muted small">น้ำหนักสินค้า: 2Kg</span>
                        </li>

                    </ul>
                </div>

                <div class="card-footer p-4">

                </div>
            </div>
        </div>
    </div>

    <?php if (isset($component)) { $__componentOriginal06b678ea6fc36cc4d04471936415ef64 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal06b678ea6fc36cc4d04471936415ef64 = $attributes; } ?>
<?php $component = App\View\Components\Section::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mt-3']); ?>
        <div class="row">
            <div class="col-12">
                <h4>ประวัติการสั่งซื้อย้อนหลัง</h4>
            </div>
            <div class="col-12">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>วันที่</th>
                            <th>สินค้า</th>
                            <th>การชำระเงิน</th>
                            <th class="text-end">จำนวนเงิน</th>
                            <th>สถานะ</th>
                            <th>รายละเอียด</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orderHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id != $order->id): ?>
                        <tr>
                            <td>
                                <?php if (isset($component)) { $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-date','data' => ['date' => $item->orderdate]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-date'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['date' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->orderdate)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $attributes = $__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__attributesOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5)): ?>
<?php $component = $__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5; ?>
<?php unset($__componentOriginalc9a21f230eaed2e56a5c5aec9d77e0f5); ?>
<?php endif; ?>
                            </td>
                            <td><small><?php echo e($item->order_line_des); ?></small></td>
                            <td><?php echo e($item->payment_method); ?></td>
                            <td class="text-end">
                                <?php if (isset($component)) { $__componentOriginala0481f239e556c750bb81cd04382d78e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala0481f239e556c750bb81cd04382d78e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.label-price','data' => ['amount' => $item->totalamt]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('label-price'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['amount' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($item->totalamt)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $attributes = $__attributesOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__attributesOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala0481f239e556c750bb81cd04382d78e)): ?>
<?php $component = $__componentOriginala0481f239e556c750bb81cd04382d78e; ?>
<?php unset($__componentOriginala0481f239e556c750bb81cd04382d78e); ?>
<?php endif; ?><br />
                            </td>
                            <td class="">

                                <?php if (isset($component)) { $__componentOriginal73f9b773b0e99831d6746157c0ccee8b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b = $attributes; } ?>
<?php $component = App\View\Components\Order\Status::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('order.status'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Order\Status::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => ''.e($item->status).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $attributes = $__attributesOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__attributesOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b)): ?>
<?php $component = $__componentOriginal73f9b773b0e99831d6746157c0ccee8b; ?>
<?php unset($__componentOriginal73f9b773b0e99831d6746157c0ccee8b); ?>
<?php endif; ?>
                            </td>
                            <td><?php echo e($item->description); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $attributes = $__attributesOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__attributesOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal06b678ea6fc36cc4d04471936415ef64)): ?>
<?php $component = $__componentOriginal06b678ea6fc36cc4d04471936415ef64; ?>
<?php unset($__componentOriginal06b678ea6fc36cc4d04471936415ef64); ?>
<?php endif; ?>

    <?php $__env->startSection('modal'); ?>
    <div class="modal fade" id="modal-change-status" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabelSm"
        aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
        <div class="modal-dialog" role="document">
            <div class="modal-content">

                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabelSm">เปลี่ยนสถานะออเดอร์</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <?php if (isset($component)) { $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.form','data' => ['action' => ''.e(route('order.changeStatus',['order'=>$order->id])).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('order.changeStatus',['order'=>$order->id])).'']); ?>
                    <input type="hidden" name="order_id" id="order_id" value="<?php echo e($order->id); ?>">
                    <div class="modal-body">

                        <div class="form-floating mb-3">
                            <select class="form-select" id="status" name="status" required>
                                <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $_status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php if($key==$order->status): echo 'selected'; endif; ?>><?php echo e($_status); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <label for="status">เลือกสถานะ <strong class="text-danger">*</strong></label>
                        </div>

                        <div class="form-floating mb-3">
                            <textarea class="form-control" placeholder="Leave a comment here" id="description"
                                style="height: 100px" name="description" required></textarea>
                            <label for="description">เหตุผล/หมายเหตุ <strong class="text-danger">*</strong></label>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <?php if (isset($component)) { $__componentOriginal76a5a562ecfea092c39dd7341f8e47da = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal76a5a562ecfea092c39dd7341f8e47da = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.button.save','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('button.save'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal76a5a562ecfea092c39dd7341f8e47da)): ?>
<?php $attributes = $__attributesOriginal76a5a562ecfea092c39dd7341f8e47da; ?>
<?php unset($__attributesOriginal76a5a562ecfea092c39dd7341f8e47da); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal76a5a562ecfea092c39dd7341f8e47da)): ?>
<?php $component = $__componentOriginal76a5a562ecfea092c39dd7341f8e47da; ?>
<?php unset($__componentOriginal76a5a562ecfea092c39dd7341f8e47da); ?>
<?php endif; ?>
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fi fi-close"></i>
                            ปิด
                        </button>
                    </div>
                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $attributes = $__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__attributesOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab)): ?>
<?php $component = $__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab; ?>
<?php unset($__componentOriginalf9a5f060e1fbbcbc7beb643b113b10ab); ?>
<?php endif; ?>

            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\projects\Git\orderpage\resources\views/pages/order/edit.blade.php ENDPATH**/ ?>