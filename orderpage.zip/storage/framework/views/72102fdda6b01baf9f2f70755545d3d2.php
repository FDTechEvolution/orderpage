<div class="form-floating mb-3">
    <select class="form-select" name="product_category_id" id="product_category_id">
        <?php if($all): ?>
        <option value="" selected>-- ทั้งหมด --</option>
        <?php endif; ?>
        <?php $__currentLoopData = $productCategoryOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($key); ?>"><?php echo e($text); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </select>
    <label for="product_category_id">กลุ่มสินค้า</label>
</div>
<?php /**PATH D:\projects\Git\orderpage\resources\views/components/selection-product-category.blade.php ENDPATH**/ ?>