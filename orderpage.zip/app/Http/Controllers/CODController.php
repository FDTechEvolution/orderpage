<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;

class CODController extends Controller
{
    public function index(){
        $startDate = '';
        $endDate = '';
        $dateRange = request()->date_range;
        if(!empty($dateRange)){
            $splits = explode('-',$dateRange);
            $startDate = trim($splits[0]);
            $endDate = trim($splits[1]);
        }

        if(empty($startDate)){
            $startDate = Carbon::now()->startOfMonth()->format('d/m/Y');
        }
        if(empty($endDate)){
            $endDate = Carbon::now()->endOfMonth()->format('d/m/Y');
        }

        $startDateSql = Carbon::createFromFormat('d/m/Y',$startDate)->format('Y-m-d');
        $endDateSql = Carbon::createFromFormat('d/m/Y',$endDate)->format('Y-m-d');

        $orders = Order::where('status','ST')->where('org_id',getOrgId())
        ->where('payment_method','COD')
        ->where('is_cod_received','N')
        ->where('orderdate','>=',$startDateSql)
        ->where('orderdate','<=',$endDateSql)
        ->with(['customer'])->get();

        return view('pages.cod.index',[
            'title'=>'ตรวจสอบยอดเงิน COD',
            'orders'=>$orders,
            'startDate'=>$startDate,
            'endDate'=>$endDate
        ]);
    }

    public function upload(){

        return view('pages.cod.upload',[
            'title'=>'อัพโหลดรายงาน COD'
        ]);
    }

    public function storeUpload(Request $request){
        $request->validate([
            'file' => 'required|file|mimes:xlsx,xls,csv'
        ]);

        // อ่านไฟล์ Excel และดึงข้อมูลเก็บในตัวแปร array
        $path = $request->file('file')->getRealPath();
        $data = Excel::toArray([], $path);
        //dd($data);
        if(empty($data) || sizeof($data)==0){
            session()->flash('error', 'ไม่สามารถอ่านไฟล์ได้');
            return redirect()->route('cod.index');
        }
        $firstSheet = $data[0];
        if(empty($firstSheet) || sizeof($firstSheet)==0){
            session()->flash('error', 'ไม่สามารถอ่านไฟล์ได้');
            return redirect()->route('cod.index');
        }

        $columns = $firstSheet[0];

        return view('pages.cod.upload',[
            'title'=>'อัพโหลดรายงาน COD',
            'columns'=>$columns,
            'data'=>$firstSheet
        ]);
    }
}
