<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class OrderController extends Controller
{
    public static function getOrderStatuses(){
        return [
            'DR'=>'ฉบับร่าง',
            'CF'=>'ยืนยัน',
            'P1'=>'ปริ้น',
            'WS'=>'รอจัดส่ง',
            'ST'=>'ส่งแล้ว',
            'VO'=>'ยกเลิกออเดอร์',
            'VO_RETURN' => 'ปฏิเสธรับสินค้า',
            'RECEIVED' => 'ได้รับสินค้าแล้ว',
        ];
    }
}
