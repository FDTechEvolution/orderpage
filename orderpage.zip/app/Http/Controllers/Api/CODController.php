<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class CODController extends Controller
{


    public function check($trackingno='',$amount=0){
        if(empty($trackingno)){
            return response()->json(['message' => 'ไม่พบออเดอร์ในระบบ','success'=>false]);
        }

        $order = Order::where('trackingno',$trackingno)->first();
        if(empty($order)){
            return response()->json(['message' => 'ไม่พบออเดอร์ในระบบ','success'=>false]);
        }

        $order->is_cod_received = 'Y';
        $order->cod_receivedamt = $amount;
        $order->save();

        $msg = sprintf('%s ยอดเงิน %s',$order->order_line_des,number_format($order->totalamt,2));
        return response()->json(['message' => $msg,'success'=>true]);
    }
}
